# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '93a82a93800e030a9f5c68dc2a88567a41bbf587588d3f57f2c6d4ddaae2d76adf8a50a5d448b71b320f69e447987e7d4c45c9d4f63061abcbffd02cf19208d4'